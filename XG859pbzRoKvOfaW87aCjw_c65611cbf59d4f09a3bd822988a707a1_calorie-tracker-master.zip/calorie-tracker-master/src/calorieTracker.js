const calculateWeightLostInAMonth = (cycling,running,swimming,extraCalorieInTake) =>{
   let weightLostInAMonth = 0;

   // write logic here 

   return weightLostInAMonth;
   
}

module.exports = calculateWeightLostInAMonth

