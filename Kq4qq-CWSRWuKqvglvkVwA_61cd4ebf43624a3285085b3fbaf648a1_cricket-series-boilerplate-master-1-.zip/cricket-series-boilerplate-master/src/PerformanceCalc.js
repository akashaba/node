
const PerformanceCalculator=(runs,balls)=>{
      // Write the Logic here
}

module.exports={PerformanceCalculator}
