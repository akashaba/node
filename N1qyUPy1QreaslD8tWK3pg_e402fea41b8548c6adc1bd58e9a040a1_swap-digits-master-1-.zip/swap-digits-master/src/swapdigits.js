const swapDigits = (number)=>{
    let swappedNumber = 0
    //write logic here
    return swappedNumber;
    
}

module.exports = swapDigits
