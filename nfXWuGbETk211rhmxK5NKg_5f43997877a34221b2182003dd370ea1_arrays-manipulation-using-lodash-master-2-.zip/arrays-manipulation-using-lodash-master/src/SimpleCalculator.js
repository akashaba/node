

//Create function addNumbers which will take two parameters add the numbers 
//and return the result


//Create function subNumbers which will take two parameters subtract the numbers 
//and return the result


//Create function mulNumbers which will take two parameters multiply the numbers 
//and return the result


//Create function divNumbers which will take two parameters divide the numbers 
//and return the result


module.exports = {
  addNumbers,
  subNumbers,
  mulNumbers,
  divNumbers
}